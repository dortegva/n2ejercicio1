public class VendaBuidaException extends Exception {
    public  VendaBuidaException(String missatge) {
        super(missatge);
    }
}
